import { prisma } from "@/lib/prisma";
import { hashPassword, signToken, setAuthCookie } from "@/lib/auth";
import { json, error } from "@/lib/api";
import { z } from "zod";

const schema = z.object({
  name: z.string().min(2),
  email: z.string().email(),
  password: z.string().min(6),
  role: z.enum(["pair", "contractor"]).default("pair"),
  city: z.string().optional(),
});

export async function POST(req: Request) {
  try {
    const body = schema.parse(await req.json());
    const email = body.email.toLowerCase();
    if (email === "igor@dreamwedding.dev") return error("Email зарезервирован", 400);
    const exists = await prisma.user.findUnique({ where: { email } });
    if (exists) return error("Email уже зарегистрирован", 409);

    const user = await prisma.user.create({
      data: {
        name: body.name,
        email,
        passwordHash: await hashPassword(body.password),
        role: body.role,
        city: body.city || null,
      },
    });

    if (body.role === "contractor") {
      await prisma.contractor.create({
        data: {
          userId: user.id,
          name: body.name,
          type: "ведущий",
          city: body.city || "Москва",
          price: 50000,
          travel: true,
          radius: 150,
          tags: ["новый"],
        },
      });
    }

    const token = await signToken({ sub: user.id, role: user.role, email: user.email });
    await setAuthCookie(token);
    return json({
      user: { id: user.id, name: user.name, email: user.email, role: user.role, city: user.city },
    });
  } catch (e: any) {
    if (e?.name === "ZodError") return error("Неверные данные", 400);
    console.error(e);
    return error("Ошибка сервера", 500);
  }
}
