import { prisma } from "@/lib/prisma";
import { json, error } from "@/lib/api";
import { getSession } from "@/lib/auth";
import { z } from "zod";

const schema = z.object({
  contractorId: z.string(),
  clientName: z.string().min(2),
  contact: z.string().min(3),
  date: z.string().optional(),
  note: z.string().optional(),
});

export async function POST(req: Request) {
  try {
    const body = schema.parse(await req.json());
    const user = await getSession();
    const contractor = await prisma.contractor.findUnique({ where: { id: body.contractorId } });
    if (!contractor) return error("Подрядчик не найден", 404);

    const item = await prisma.request.create({
      data: {
        contractorId: body.contractorId,
        clientId: user?.id || null,
        clientName: body.clientName,
        contact: body.contact,
        date: body.date || null,
        note: body.note || null,
      },
    });
    return json({ item }, 201);
  } catch (e: any) {
    if (e?.name === "ZodError") return error("Неверные данные", 400);
    console.error(e);
    return error("Ошибка", 500);
  }
}

export async function GET() {
  const user = await getSession();
  if (!user) return error("Не авторизован", 401);

  if (user.role === "developer") {
    const items = await prisma.request.findMany({
      orderBy: { createdAt: "desc" },
      take: 100,
      include: { contractor: true },
    });
    return json({ items });
  }

  if (user.role === "contractor") {
    const profile = await prisma.contractor.findFirst({ where: { userId: user.id } });
    if (!profile) return json({ items: [] });
    const items = await prisma.request.findMany({
      where: { contractorId: profile.id },
      orderBy: { createdAt: "desc" },
    });
    return json({ items });
  }

  const items = await prisma.request.findMany({
    where: { clientId: user.id },
    orderBy: { createdAt: "desc" },
    include: { contractor: true },
  });
  return json({ items });
}
