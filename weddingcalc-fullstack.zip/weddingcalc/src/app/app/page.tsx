export default function AppPage() {
  return (
    <main style={{ padding: 40, fontFamily: "system-ui" }}>
      <p>
        Статический прототип UI:{" "}
        <a href="/app.html" style={{ color: "#A67C52" }}>
          /app.html
        </a>
      </p>
      <p style={{ color: "#7A6F63", fontSize: 14 }}>
        Сейчас UI на localStorage. API уже общее — следующий шаг связать fetch.
      </p>
    </main>
  );
}
