import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Wedding Calc PRO — свадебный калькулятор по России",
  description: "Сценарий дня, смета и подрядчики по всей России",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ru">
      <body style={{ margin: 0, fontFamily: "Georgia, serif", background: "#FDFBF7", color: "#1A1612" }}>
        {children}
      </body>
    </html>
  );
}
