import { prisma } from "@/lib/prisma";
import { json, error } from "@/lib/api";
import { getSession } from "@/lib/auth";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const city = searchParams.get("city");
  const type = searchParams.get("type");
  const travel = searchParams.get("travel");
  const take = Math.min(Number(searchParams.get("limit") || 50), 100);
  const skip = Number(searchParams.get("offset") || 0);

  const where: any = { active: true };
  if (city) where.city = { contains: city, mode: "insensitive" };
  if (type) where.type = type;
  if (travel === "true") where.travel = true;
  if (travel === "false") where.travel = false;

  const [items, total] = await Promise.all([
    prisma.contractor.findMany({
      where,
      orderBy: [{ rating: "desc" }, { name: "asc" }],
      take,
      skip,
    }),
    prisma.contractor.count({ where }),
  ]);

  return json({ items, total });
}

export async function POST(req: Request) {
  const user = await getSession();
  if (!user || (user.role !== "developer" && user.role !== "contractor")) {
    return error("Нет доступа", 403);
  }
  try {
    const body = await req.json();
    const item = await prisma.contractor.create({
      data: {
        name: body.name,
        type: body.type || "ведущий",
        city: body.city || "Москва",
        price: Number(body.price) || 50000,
        rating: Number(body.rating) || 4.5,
        travel: Boolean(body.travel),
        radius: Number(body.radius) || 0,
        tags: body.tags || [],
        userId: user.role === "contractor" ? user.id : body.userId || null,
      },
    });
    return json({ item }, 201);
  } catch (e) {
    console.error(e);
    return error("Ошибка создания", 500);
  }
}
