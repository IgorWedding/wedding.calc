import Link from "next/link";

export default function HomePage() {
  return (
    <main style={{ maxWidth: 720, margin: "0 auto", padding: "48px 20px" }}>
      <p style={{ fontSize: 12, letterSpacing: "0.2em", textTransform: "uppercase", color: "#A67C52" }}>
        Wedding Calc PRO
      </p>
      <h1 style={{ fontSize: 40, lineHeight: 1.2, margin: "12px 0 16px" }}>
        Бэкенд готов. Данные общие для всех.
      </h1>
      <p style={{ fontFamily: "system-ui", color: "#5C5248", lineHeight: 1.6, marginBottom: 28 }}>
        API: регистрация, вход, подрядчики, заявки, премиум (admin).
        Подключи PostgreSQL, выполни миграцию и задеплой.
      </p>
      <ul style={{ fontFamily: "system-ui", lineHeight: 1.9, color: "#3D352D" }}>
        <li>
          <code>POST /api/auth/register</code>
        </li>
        <li>
          <code>POST /api/auth/login</code>
        </li>
        <li>
          <code>GET /api/auth/me</code>
        </li>
        <li>
          <code>GET /api/contractors</code>
        </li>
        <li>
          <code>POST /api/requests</code>
        </li>
        <li>
          <code>POST /api/admin/premium</code> (только developer)
        </li>
        <li>
          <code>GET /api/articles</code>
        </li>
      </ul>
      <p style={{ fontFamily: "system-ui", fontSize: 14, color: "#7A6F63", marginTop: 32 }}>
        DEV: igor@dreamwedding.dev / IgorDev2026!
        <br />
        Разработка: Igor Minasyan · dreamwedding@internet.ru
      </p>
      <p style={{ marginTop: 24 }}>
        <Link href="/app" style={{ color: "#A67C52" }}>
          Открыть прототип UI →
        </Link>
      </p>
    </main>
  );
}
